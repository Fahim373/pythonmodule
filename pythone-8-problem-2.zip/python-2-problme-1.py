user_name = input("Please enter your name: ")
if user_name:
    print(f"Hello, {user_name}!")
else:
    print("Hello, World!")
