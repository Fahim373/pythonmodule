def sum_of_list(numbers):
    total = sum(numbers)
    return total
if __name__ == "__main__":
    integer_list = [1, 2, 3, 4, 5]
    result = sum_of_list(integer_list)
    print(f"The sum of the list is: {result}")
