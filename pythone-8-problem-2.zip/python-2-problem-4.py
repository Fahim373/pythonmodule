

num1 = int(input(" enter  first integer number: "))
num2 = int(input(" enter second integer number: "))
num3 = int(input(" enter  third integer number: "))
total = num1 + num2 + num3
product = num1 * num2 * num3
average = total / 3
print(f"The sum of the numbers is: {total}")
print(f"The product of the numbers is: {product}")
print(f"The average of the numbers is: {average:.2f}")
