number = 1
while number <= 1000:
    if number % 3 == 0:
        print(number)
    number += 1